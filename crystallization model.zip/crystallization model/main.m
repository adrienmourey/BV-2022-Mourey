clear all

%load all parameters and compositions

load('CL_0.mat')    %initial melt composition
load('CS_0.mat')    %initial olivine composition
load('ox_wt_L.mat') %oxide weight percents of liquid components with silica in Si0.5O form
load('ox_wt_S.mat') %oxide weight percents of solid components with silica in SiO2 form
load('mult_mat.mat')%multiplication matrix used in DNi calculation following Matzen et al. 2013


%define PT conditions
Ti=1360+273.15;%initial temperature in deg K
Tf=1170+273;%final temperature in deg K
P=80;%crystallization pressure in MPa
P_bar=P*10;
deltaQFM=0;

%reassign variables and calculate Fo for current liq and solid
CL_new=100.*(CL_0./sum(CL_0)); %normalize liquid composition to 100
CS_new=100.*(CS_0./sum(CS_0)); %normalize olivine composition to 100

%main crystallization section
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
dT=1;   %cooling timestep in degrees
T=round(Tf):dT:round(Ti);   %create temperature array without decimals
nfc=length(T);  %length of T array

%pre-allocate solid and melt concentration variables to accomodate all crystallization steps
CS_old_fc=zeros(12,nfc); %olivine
CL_old_fc=zeros(12,nfc); %melt

%pre-allocate solid-melt partition coefficient variables to accomodate all crystallization steps
D_new_fc=zeros(12,nfc); %olivine

%assign initial solid and melt concentrations to new variable
CL_new_fc=CL_new;
CS_new_fc=CS_new;

%define the expected variation in olivine fraction as a function of temperature
x_ol=0.01.*(-1.399E-04.*(T-273.15).^2 + 2.454E-01.*(T-273.15) - 7.579E+01);%(-1.739E-04.*(T-273.15).^2 + 3.333E-01.*(T-273.15) - 1.181E+02)-0.1628;%(-1.1621E-04.*(T-273.15).^2 + 1.7958E-01.*(T-273.15) - 3.8845E+01);%from melts crystallization run
x_ol=[fliplr(x_ol)];
x_ol(x_ol<0)=0;


for i=1:nfc
    T=Ti-(i.*dT); %current temperature
    T_all(i)=T;
    %
    sum_CL_perc=sum(CL_new_fc);
    
    %recalculate Fe2O3-FeO
    fe3_fe2_calculate
    if i>1
        x_ol_inc=x_ol(i)-x_ol(i-1); %fraction of newly crystallized olivine
    else
        x_ol_inc=x_ol(i);
    end
    
    x=(x_ol(i));%total fraction currently crystallized
    x_ol_t=(x_ol(i))%olivine fraction currently crystallized
    
    %CRYSTALLIZATION
    %normalize concentration in solids
    CS_old_fc(:,i)=100.*(CS_new_fc./sum(CS_new_fc)); %olivine

    %normalize concentration in liquid
    CL_old_fc(:,i)=100.*(CL_new_fc./sum(CL_new_fc)); %melt
    
    if x_ol_inc>0
        
        %calculate liquid composition on molar basis
        CL_mol_fc=CL_old_fc(:,i)./ox_wt_L;%using Si0.5O
        CL_mol2_fc=CL_old_fc(:,i)./ox_wt_S;%using SiO2
        sum_CL_mol_fc=sum(CL_mol_fc);
        sum_CL_mol2_fc=sum(CL_mol2_fc);
        CL_molfrac_fc=CL_mol_fc./sum_CL_mol_fc;
        CL_molfrac2_fc=CL_mol2_fc./sum_CL_mol2_fc;
        
        %olivine components on molar basis and calculate DNi based on Matzen et al. 2013
        CS_mol_fc=CS_new_fc./ox_wt_S;%using SiO2
        sum_CS_mol_fc=sum(CS_mol_fc);
        CS_molfrac_fc=CS_mol_fc./sum_CS_mol_fc;
        %create array containing only SiO2, FeO, MnO, MgO, CaO, NiO
        CS_ol_comp1_fc=mult_mat*([CS_molfrac_fc(1);CS_molfrac_fc(5);CS_molfrac_fc(6);...
            CS_molfrac_fc(7);CS_molfrac_fc(8);CS_molfrac_fc(12)]);
        sum_CS_ol_comp_fc=sum(CS_ol_comp1_fc(2:6)); %SiO2 is excluded from the olivine like components
        %final olivine end-member compositions
        CS_ol_comp_fc=CS_ol_comp1_fc./sum_CS_ol_comp_fc;
        %predict DNi based on empirical formulation of Matzen et al. 2012
        DNi_mol_th_fc=exp((4337.9665.*(1/T))-1.9563-log(CL_molfrac_fc(7)./CS_ol_comp_fc(4)));
        %express DNi in weight percent
        DNi_wt_th_fc(i)=DNi_mol_th_fc.*((sum_CS_mol_fc.*sum_CS_ol_comp_fc)./sum_CL_mol_fc);
              
        Fo_S_fc(:,i)=100.*(CS_old_fc(7,i)./ox_wt_S(7))/((CS_old_fc(7,i)./ox_wt_S(7))+(CS_old_fc(5,i)./ox_wt_S(5)));
        
        %calculate DFe and DMg
             
        %DMg from Putirka et al. 2007
        D_Mg(i)=exp(-2.158+(55.09*((P./1000)./(T-273.15)))-(6.213*10^-2*0.5)+(4430./(T-273.15))+5.115*10^-2*(CL_old_fc(9,i)+CL_old_fc(10,i)));
        
        %fixed Kd from Shea et al. in prep
        KD_mod(i)=0.334;
        
        %DFe calculated using Kd
        D_Fe(i)=KD_mod(i).*D_Mg(i);
        
        %main calculation
        D_new_fc(:,i)=CS_old_fc(:,i)./CL_old_fc(:,i);
        sum_D(i)=sum((CS_old_fc(:,i)./CL_old_fc(:,i)));
        
        D_new_fc(12,i)=DNi_wt_th_fc(i);%impose DNi from calculation above
        D_new_fc(7,i)=D_Mg(i);%impose DMg from calculation above
        D_new_fc(5,i)=D_Fe(i)./(1+0.8998.*Fe_ratio(i));%impose DFe from calculation above
        D_new_fc(1,i)=0.78;%Si
        D_new_fc(4,i)=1;%not used
        D_new_fc(6,i)=1.3;%Mn
        D_new_fc(2,i)=0.015;%Ti
        D_new_fc(8,i)=0.03;%Ca
        D_new_fc(3,i)=0.001;%Al
        D_new_fc(11,i)=0.001;%P
        
        CL_new_fc=CL_old_fc(:,i)./(D_new_fc(:,i).*(x_ol_inc)+(1-(x_ol_inc)));
        
        CS_new_fc=D_new_fc(:,i).*CL_new_fc;        
                
    end
end

Fo_S_fc(x_ol==0)=[];%remove all 'imaginary' compositions from when x=0
CS_old_fc(:,x_ol==0)=[];%remove all 'imaginary' compositions from when x=0

Fo_S_fc(:,1:2)=[];%remove first solid compositions (usually not perfectly equilibrated)
CS_old_fc(:,1:2)=[];%remove first solid composition (usually not perfectly equilibrated)

%plot Ni vs. Fo
scatter(Fo_S_fc,CS_old_fc(12,:));axis([75 90 0.1 0.45])