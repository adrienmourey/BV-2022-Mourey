if exist('i','var')==0
    Tfe=Ti; 
else
    Tfe=T;
end

CL_new_fe=zeros(12,1);
CL_new_fe(1)=CL_new_fc(1)*(100./sum_CL_perc);
CL_new_fe(2)=CL_new_fc(2)*(100./sum_CL_perc);
CL_new_fe(3)=CL_new_fc(3)*(100./sum_CL_perc);
CL_new_fe(4)=CL_new_fc(4)*(100./sum_CL_perc);
CL_new_fe(5)=CL_new_fc(5)*(100./sum_CL_perc);%+0.8998.*CL_new_fc(4))
CL_new_fe(6)=CL_new_fc(6)*(100./sum_CL_perc);
CL_new_fe(7)=CL_new_fc(7)*(100./sum_CL_perc);
CL_new_fe(8)=CL_new_fc(8)*(100./sum_CL_perc);
CL_new_fe(9)=CL_new_fc(9)*(100./sum_CL_perc);
CL_new_fe(10)=CL_new_fc(10)*(100./sum_CL_perc);
CL_new_fe(11)=CL_new_fc(11)*(100./sum_CL_perc);
CL_new_fe(12)=CL_new_fc(12)*(100./sum_CL_perc);
%CL_new_fe=CL_new_fe';
CL_new_mol=CL_new_fe./ox_wt_S;
sum_CL_new_mol=sum(CL_new_mol);
XL_new_mol=CL_new_mol./sum_CL_new_mol;


%calculate fO2 using Kress and Carmichael 1991
A_kc=-25096.3; %QFM
B_kc=8.735;
C_kc=0.11;
logfO2=(A_kc/Tfe+B_kc+C_kc.*(P_bar-1)./Tfe);
fO2_bar=10^(logfO2+deltaQFM); %fO2 in bars
P_Pa=P_bar.*10^5;

%calculate ln(XFe2O3/XFeO) using Kress & Carmichael 1991
a_kc=0.196;
b_kc=11492;
c_kc=-6.675;
e_kc=-3.36;
f_kc=-0.000000701;
g_kc=-1.54*10^-10;
h_kc=3.85*10^-17;
dAl2O3=-2.243;
dFeO=-1.828;
dCaO=3.201;
dNa2O=5.854;
dK2O=6.215;
T0=1673; %reference temp

lnXfe2O3Xfeo=a_kc.*log(fO2_bar)+(b_kc./Tfe)+c_kc+...
    (dAl2O3.*XL_new_mol(3)+dFeO.*XL_new_mol(5)+dCaO.*XL_new_mol(8)+dNa2O.*XL_new_mol(9)+dK2O.*XL_new_mol(10))...
    +e_kc.*(1-(T0./Tfe)-log(Tfe./T0))+f_kc.*(P_Pa/Tfe)+g_kc.*((Tfe-T0).*(P_Pa/Tfe))+h_kc.*((P_Pa.^2)/Tfe);

%recalculate melt composition with fe3+

Xfe2O3Xfeo=exp(lnXfe2O3Xfeo);
Xfe2O3=Xfe2O3Xfeo*XL_new_mol(5)/(2*Xfe2O3Xfeo+1);
XfeO=Xfe2O3/Xfe2O3Xfeo;

XL_new_mol(4)=Xfe2O3;
XL_new_mol(5)=XfeO;

XL_molw=XL_new_mol.*ox_wt_S;
sumXL_mol=sum(XL_molw);

CL_new_fe3=100.*XL_molw./sumXL_mol;

Fe_ratio(i)=CL_new_fe3(4)./CL_new_fe3(5);
